--namedSpawnables (CLIENT)

local M = {}

local function namedMessage(msg)
	guihooks.trigger('Message', {ttl = 10, msg = msg, category = "fill", icon = "flag"})
end

local function onExtensionLoaded()
	log("M","namedSpawnables","Loading namedSpawnables")
	AddEventHandler("namedMessage", namedMessage)
end

local function onExtensionUnloaded()
	log("M","namedSpawnables","Unloading namedSpawnables")
	Lua:requestReload()
end

M.namedMessage = namedMessage

M.onExtensionLoaded = onExtensionLoaded
M.onExtensionUnloaded = onExtensionUnloaded

return M
