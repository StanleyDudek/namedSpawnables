load("namedSpawnables")
registerCoreModule("namedSpawnables")